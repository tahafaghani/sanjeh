from __future__ import annotations

from validator.types import CellValue


def normalize_header(value: str) -> str:
    text = value.strip().lower()
    text = "".join(" " if ch in "-–—" else ch for ch in text)
    collapsed = "_".join(text.split())
    while "__" in collapsed:
        collapsed = collapsed.replace("__", "_")
    return collapsed


def find_header(headers: list[str], aliases: tuple[str, ...]) -> str | None:
    wanted = {normalize_header(alias) for alias in aliases}
    for header in headers:
        if normalize_header(header) in wanted:
            return header
    return None


def cell_text(value: CellValue | None) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _finite_number(number: float) -> float | int | None:
    if number != number or number in (float("inf"), float("-inf")):
        return None
    if float(number).is_integer():
        return int(number)
    return float(number)


def parse_number(value: CellValue | None) -> float | int | None:
    if value is None or value is False or value is True:
        return None
    if isinstance(value, int) and not isinstance(value, bool):
        return value
    if isinstance(value, float):
        return _finite_number(value)
    text = str(value).strip().replace(",", "")
    if not text:
        return None
    try:
        number = float(text)
    except ValueError:
        return None
    return _finite_number(number)


def lookup_cell(row: dict[str, CellValue], aliases: tuple[str, ...]) -> CellValue | None:
    wanted = {normalize_header(alias) for alias in aliases}
    for key, value in row.items():
        if normalize_header(key) in wanted:
            return value
    return None


def lookup_by_name(row: dict[str, CellValue], name: str) -> tuple[bool, CellValue | None]:
    wanted = normalize_header(name)
    for key, value in row.items():
        if normalize_header(key) == wanted:
            return True, value
    return False, None
