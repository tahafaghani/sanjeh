"""Deterministic product-to-standard validation engine."""

from validator.engine import summarize, validate_product, validate_products
from validator.messages import format_failure_en, format_failure_fa
from validator.parse import find_product_sheet, find_standard_sheet, parse_products, parse_standards
from validator.reporter import build_results_workbook, workbook_bytes
from validator.run import run_validation, run_validation_from_bytes, run_validation_from_paths

__all__ = [
    "build_results_workbook",
    "find_product_sheet",
    "find_standard_sheet",
    "format_failure_en",
    "format_failure_fa",
    "parse_products",
    "parse_standards",
    "run_validation",
    "run_validation_from_bytes",
    "run_validation_from_paths",
    "summarize",
    "validate_product",
    "validate_products",
    "workbook_bytes",
]
