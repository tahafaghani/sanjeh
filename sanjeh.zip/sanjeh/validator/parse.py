from __future__ import annotations

from validator.normalize import (
    cell_text,
    find_header,
    lookup_cell,
    normalize_header,
    parse_number,
)
from validator.schema import (
    IDENTITY_FIELDS,
    PRODUCT_SHEET_NAMES,
    STANDARD_FIELDS,
    STANDARD_SHEET_NAMES,
)
from validator.types import ParsedWorkbook, ParseIssue, ProductRecord, StandardRule, TabularSheet


def _pick_sheet(workbook: ParsedWorkbook, names: tuple[str, ...]) -> TabularSheet | None:
    wanted = {normalize_header(name) for name in names}
    for name in workbook.sheet_names:
        if normalize_header(name) in wanted:
            return workbook.sheets[name]
    return None


def find_product_sheet(workbook: ParsedWorkbook) -> TabularSheet | None:
    return _pick_sheet(workbook, PRODUCT_SHEET_NAMES)


def find_standard_sheet(workbook: ParsedWorkbook) -> TabularSheet | None:
    return _pick_sheet(workbook, STANDARD_SHEET_NAMES)


def parse_products(sheet: TabularSheet) -> tuple[list[ProductRecord], list[ParseIssue]]:
    issues: list[ParseIssue] = []
    id_header = find_header(sheet.headers, IDENTITY_FIELDS["id"])
    name_header = find_header(sheet.headers, IDENTITY_FIELDS["name"])
    category_header = find_header(sheet.headers, IDENTITY_FIELDS["category"])

    if not category_header:
        issues.append(ParseIssue(sheet=sheet.name, message="ستون Category در شیت محصولات پیدا نشد."))

    identity = {
        normalize_header(header)
        for header in (id_header, name_header, category_header)
        if header
    }

    products: list[ProductRecord] = []
    for index, row in enumerate(sheet.rows):
        source_row = index + 2
        product_id = cell_text(row.get(id_header) if id_header else None) or f"ROW-{source_row}"
        name = cell_text(row.get(name_header) if name_header else None) or product_id
        category = cell_text(row.get(category_header) if category_header else None)

        values: dict[str, object] = {}
        for key, value in row.items():
            if normalize_header(key) in identity:
                continue
            values[key] = value

        if not category:
            issues.append(
                ParseIssue(
                    sheet=sheet.name,
                    row=source_row,
                    message=f"ردیف {source_row} ({product_id}) دسته ندارد.",
                )
            )

        products.append(
            ProductRecord(
                id=product_id,
                name=name,
                category=category,
                values=values,  # type: ignore[arg-type]
                source_row=source_row,
            )
        )

    return products, issues


def parse_standards(sheet: TabularSheet) -> tuple[list[StandardRule], list[ParseIssue]]:
    issues: list[ParseIssue] = []
    category_header = find_header(sheet.headers, STANDARD_FIELDS["category"])
    parameter_header = find_header(sheet.headers, STANDARD_FIELDS["parameter"])
    min_header = find_header(sheet.headers, STANDARD_FIELDS["min"])
    max_header = find_header(sheet.headers, STANDARD_FIELDS["max"])
    unit_header = find_header(sheet.headers, STANDARD_FIELDS["unit"])

    if not category_header or not parameter_header or not min_header or not max_header:
        issues.append(
            ParseIssue(
                sheet=sheet.name,
                message="شیت استاندارد باید ستون‌های Category، Parameter، Min_Value و Max_Value را داشته باشد.",
            )
        )
        return [], issues

    standards: list[StandardRule] = []
    for index, row in enumerate(sheet.rows):
        source_row = index + 2
        category = cell_text(lookup_cell(row, STANDARD_FIELDS["category"]))
        parameter = cell_text(lookup_cell(row, STANDARD_FIELDS["parameter"]))
        unit = cell_text(row.get(unit_header) if unit_header else None)
        min_parsed = parse_number(row.get(min_header) if min_header else None)
        max_parsed = parse_number(row.get(max_header) if max_header else None)

        if not category or not parameter:
            issues.append(
                ParseIssue(
                    sheet=sheet.name,
                    row=source_row,
                    message=f"ردیف {source_row} استاندارد ناقص است (دسته یا پارامتر خالی).",
                )
            )
            continue
        if min_parsed is None or max_parsed is None:
            issues.append(
                ParseIssue(
                    sheet=sheet.name,
                    row=source_row,
                    message=f"ردیف {source_row} ({parameter}) حداقل/حداکثر عددی نیست.",
                )
            )
            continue
        if min_parsed > max_parsed:
            issues.append(
                ParseIssue(
                    sheet=sheet.name,
                    row=source_row,
                    message=f"ردیف {source_row} ({parameter}): حداقل از حداکثر بزرگ‌تر است.",
                )
            )
            continue

        standards.append(
            StandardRule(
                category=category,
                parameter=parameter,
                min=min_parsed,
                max=max_parsed,
                unit=unit,
            )
        )

    return standards, issues
