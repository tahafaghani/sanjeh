from __future__ import annotations

from io import BytesIO

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from validator.messages import format_failure_en, format_failure_fa
from validator.types import ValidationRun

SLATE = "3D4A52"
PASS = "2F6A4A"
FAIL = "9A3D35"
LINE = "D9D4CC"


def _fill(hex_color: str) -> PatternFill:
    return PatternFill("solid", fgColor=hex_color)


def _border() -> Border:
    side = Side(style="thin", color=LINE)
    return Border(left=side, right=side, top=side, bottom=side)


def _style_header(worksheet: Worksheet, columns: int) -> None:
    font = Font(name="Calibri", bold=True, color="F6F4F0")
    fill = _fill(SLATE)
    for index in range(1, columns + 1):
        cell = worksheet.cell(1, index)
        cell.font = font
        cell.fill = fill
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = _border()
    worksheet.row_dimensions[1].height = 22
    worksheet.auto_filter.ref = worksheet.dimensions
    worksheet.freeze_panes = "A2"


def _autosize(worksheet: Worksheet, min_width: int = 12, max_width: int = 56) -> None:
    for column in worksheet.columns:
        letter = get_column_letter(column[0].column)
        width = min_width
        for cell in column:
            value = "" if cell.value is None else str(cell.value)
            width = max(width, min(max_width, len(value) + 2))
        worksheet.column_dimensions[letter].width = width


def _status_fill(status: str) -> PatternFill:
    return _fill("DCE8E0") if status == "APPROVED" else _fill("F3DDD9")


def build_results_workbook(run: ValidationRun) -> Workbook:
    workbook = Workbook()

    summary = workbook.active
    summary.title = "Summary"
    summary.append(
        ["ID", "Product", "Category", "Status", "Failed_Count", "Reasons", "Reasons_FA"]
    )
    for result in run.results:
        reasons_en = " | ".join(format_failure_en(failure) for failure in result.failures)
        reasons_fa = " | ".join(format_failure_fa(failure) for failure in result.failures)
        summary.append(
            [
                result.id,
                result.name,
                result.category,
                result.status,
                result.failed_count,
                reasons_en,
                reasons_fa,
            ]
        )
    _style_header(summary, 7)
    for row in summary.iter_rows(min_row=2, max_row=summary.max_row, max_col=7):
        status = row[3].value
        fill = _status_fill(str(status))
        for cell in row:
            cell.border = _border()
            cell.alignment = Alignment(vertical="center", wrap_text=True)
            cell.fill = fill
            if cell.column == 4:
                cell.font = Font(bold=True, color=PASS if status == "APPROVED" else FAIL)
                cell.alignment = Alignment(horizontal="center", vertical="center")
    _autosize(summary)

    details = workbook.create_sheet("Details")
    details.append(
        [
            "ID",
            "Product",
            "Category",
            "Parameter",
            "Actual",
            "Min",
            "Max",
            "Unit",
            "Result",
            "Code",
            "Message",
            "Message_FA",
        ]
    )
    for result in run.results:
        if not result.checks and result.failures:
            failure = result.failures[0]
            details.append(
                [
                    result.id,
                    result.name,
                    result.category,
                    failure.parameter,
                    failure.actual,
                    failure.min,
                    failure.max,
                    failure.unit,
                    "FAIL",
                    failure.code,
                    format_failure_en(failure),
                    format_failure_fa(failure),
                ]
            )
            continue
        for check in result.checks:
            failure = check.failure
            details.append(
                [
                    result.id,
                    result.name,
                    result.category,
                    check.parameter,
                    check.actual,
                    check.min,
                    check.max,
                    check.unit,
                    "PASS" if check.passed else "FAIL",
                    failure.code if failure else "",
                    format_failure_en(failure) if failure else "",
                    format_failure_fa(failure) if failure else "",
                ]
            )
    _style_header(details, 12)
    for row in details.iter_rows(min_row=2, max_row=max(details.max_row, 2), max_col=12):
        if row[0].value is None:
            break
        passed = row[8].value == "PASS"
        fill = _fill("DCE8E0") if passed else _fill("F3DDD9")
        for cell in row:
            cell.border = _border()
            cell.alignment = Alignment(vertical="center", wrap_text=True)
            cell.fill = fill
            if cell.column == 9:
                cell.font = Font(bold=True, color=PASS if passed else FAIL)
                cell.alignment = Alignment(horizontal="center", vertical="center")
    _autosize(details)

    overview = workbook.create_sheet("Overview")
    overview.append(["Metric", "Value"])
    overview.append(["Total", run.summary.total])
    overview.append(["Approved", run.summary.approved])
    overview.append(["Rejected", run.summary.rejected])
    overview.append(["", ""])
    overview.append(["Parameter", "Failure_Count"])
    for item in run.summary.failures_by_parameter:
        overview.append([item["parameter"], item["count"]])
    _style_header(overview, 2)
    _autosize(overview)

    return workbook


def workbook_bytes(run: ValidationRun) -> bytes:
    workbook = build_results_workbook(run)
    buffer = BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()
