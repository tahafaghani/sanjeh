from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "samples"

DATASETS = {
    "document": {
        "id": "document",
        "title_fa": "مثال سند",
        "title_en": "Document example",
        "blurb": "محصولات داخل Standards.xlsx — همان دادهٔ مثال رسمی سند (P002 وزن ۱۲۵۰).",
        "products": DATA_DIR / "standards.xlsx",
        "standards": DATA_DIR / "standards.xlsx",
    },
    "products": {
        "id": "products",
        "title_fa": "فایل Products",
        "title_en": "Products.xlsx",
        "blurb": "شیت محصولات فایل Products.xlsx با همان جدول استاندارد.",
        "products": DATA_DIR / "products.xlsx",
        "standards": DATA_DIR / "products.xlsx",
    },
}


def dataset_meta() -> list[dict]:
    return [
        {
            "id": item["id"],
            "title_fa": item["title_fa"],
            "title_en": item["title_en"],
            "blurb": item["blurb"],
        }
        for item in DATASETS.values()
    ]


def read_dataset(dataset_id: str) -> tuple[bytes, bytes]:
    item = DATASETS.get(dataset_id)
    if item is None:
        raise KeyError(dataset_id)
    return item["products"].read_bytes(), item["standards"].read_bytes()
