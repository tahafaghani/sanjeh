from __future__ import annotations

from dataclasses import asdict

from validator.messages import format_failure_en, format_failure_fa
from validator.run import EngineFailure, EngineResult, EngineSuccess
from validator.types import CheckFailure, ParameterCheck, ParseIssue, ProductValidation, ValidationRun


def _failure_dict(failure: CheckFailure) -> dict:
    return {
        **asdict(failure),
        "message_en": format_failure_en(failure),
        "message_fa": format_failure_fa(failure),
    }


def _check_dict(check: ParameterCheck) -> dict:
    return {
        "parameter": check.parameter,
        "actual": check.actual,
        "min": check.min,
        "max": check.max,
        "unit": check.unit,
        "passed": check.passed,
        "failure": _failure_dict(check.failure) if check.failure else None,
    }


def _result_dict(result: ProductValidation) -> dict:
    return {
        "id": result.id,
        "name": result.name,
        "category": result.category,
        "status": result.status,
        "failed_count": result.failed_count,
        "checks": [_check_dict(check) for check in result.checks],
        "failures": [_failure_dict(failure) for failure in result.failures],
        "reasons_en": [format_failure_en(failure) for failure in result.failures],
        "reasons_fa": [format_failure_fa(failure) for failure in result.failures],
    }


def run_to_dict(run: ValidationRun) -> dict:
    return {
        "results": [_result_dict(result) for result in run.results],
        "summary": {
            "total": run.summary.total,
            "approved": run.summary.approved,
            "rejected": run.summary.rejected,
            "failures_by_parameter": run.summary.failures_by_parameter,
        },
        "standards": [asdict(rule) for rule in run.standards],
    }


def issue_to_dict(issue: ParseIssue) -> dict:
    return {"sheet": issue.sheet, "row": issue.row, "message": issue.message}


def result_to_payload(result: EngineResult) -> dict:
    if isinstance(result, EngineFailure) or not result.ok:
        error = result.error  # type: ignore[union-attr]
        return {
            "ok": False,
            "error": {
                "kind": error.kind,
                "message": error.message,
                "issues": [issue_to_dict(issue) for issue in error.issues],
            },
        }
    assert isinstance(result, EngineSuccess)
    return {
        "ok": True,
        "run": run_to_dict(result.run),
        "issues": [issue_to_dict(issue) for issue in result.issues],
    }
