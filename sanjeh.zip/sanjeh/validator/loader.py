from __future__ import annotations

from io import BytesIO
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.workbook import Workbook

from validator.types import CellValue, ParsedWorkbook, TabularSheet


def _coerce_cell(value: object) -> CellValue:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            return None
        if value.is_integer():
            return int(value)
        return value
    if hasattr(value, "isoformat"):
        try:
            return value.isoformat()  # type: ignore[no-any-return]
        except Exception:
            return str(value)
    return str(value)


def _sheet_from_worksheet(name: str, worksheet) -> TabularSheet:
    rows_iter = worksheet.iter_rows(values_only=True)
    try:
        header_row = next(rows_iter)
    except StopIteration:
        return TabularSheet(name=name, headers=[], rows=[])

    headers = [str(cell).strip() if cell is not None else "" for cell in header_row]
    records: list[dict[str, CellValue]] = []

    for raw in rows_iter:
        if raw is None or all(cell is None or cell == "" for cell in raw):
            continue
        record: dict[str, CellValue] = {}
        for index, header in enumerate(headers):
            if not header:
                continue
            cell = raw[index] if index < len(raw) else None
            record[header] = _coerce_cell(cell)
        records.append(record)

    return TabularSheet(name=name, headers=[h for h in headers if h], rows=records)


def workbook_from_openpyxl(workbook: Workbook) -> ParsedWorkbook:
    sheets: dict[str, TabularSheet] = {}
    for name in workbook.sheetnames:
        sheets[name] = _sheet_from_worksheet(name, workbook[name])
    return ParsedWorkbook(sheet_names=list(workbook.sheetnames), sheets=sheets)


def workbook_from_bytes(data: bytes) -> ParsedWorkbook:
    workbook = load_workbook(BytesIO(data), data_only=True, read_only=True)
    try:
        return workbook_from_openpyxl(workbook)
    finally:
        workbook.close()


def workbook_from_path(path: str | Path) -> ParsedWorkbook:
    workbook = load_workbook(path, data_only=True, read_only=True)
    try:
        return workbook_from_openpyxl(workbook)
    finally:
        workbook.close()
