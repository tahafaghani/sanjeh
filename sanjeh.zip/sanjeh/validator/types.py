from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Union

CellValue = Union[str, int, float, bool, None]

FailureCode = Literal[
    "unknown_category",
    "missing_parameter",
    "missing_value",
    "not_numeric",
    "out_of_range",
    "invalid_standard",
]

Status = Literal["APPROVED", "REJECTED"]


@dataclass(frozen=True)
class TabularSheet:
    name: str
    headers: list[str]
    rows: list[dict[str, CellValue]]


@dataclass(frozen=True)
class ParsedWorkbook:
    sheet_names: list[str]
    sheets: dict[str, TabularSheet]


@dataclass
class ProductRecord:
    id: str
    name: str
    category: str
    values: dict[str, CellValue]
    source_row: int


@dataclass(frozen=True)
class StandardRule:
    category: str
    parameter: str
    min: float
    max: float
    unit: str


@dataclass(frozen=True)
class CheckFailure:
    parameter: str
    actual: CellValue
    min: float | None
    max: float | None
    unit: str
    code: FailureCode


@dataclass(frozen=True)
class ParameterCheck:
    parameter: str
    actual: CellValue
    min: float
    max: float
    unit: str
    passed: bool
    failure: CheckFailure | None = None


@dataclass
class ProductValidation:
    id: str
    name: str
    category: str
    status: Status
    failed_count: int
    checks: list[ParameterCheck] = field(default_factory=list)
    failures: list[CheckFailure] = field(default_factory=list)


@dataclass
class ValidationSummary:
    total: int
    approved: int
    rejected: int
    failures_by_parameter: list[dict[str, object]]


@dataclass
class ValidationRun:
    products: list[ProductRecord]
    standards: list[StandardRule]
    results: list[ProductValidation]
    summary: ValidationSummary


@dataclass(frozen=True)
class ParseIssue:
    sheet: str
    message: str
    row: int | None = None
