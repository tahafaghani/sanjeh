from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from validator.reporter import workbook_bytes
from validator.run import EngineSuccess, run_validation_from_bytes, run_validation_from_paths
from validator.samples import DATASETS, read_dataset
from validator.serialize import result_to_payload


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m validator",
        description="Validate product Excel rows against a long-format standards sheet.",
    )
    parser.add_argument("--products", type=Path, help="Workbook that contains a Products sheet")
    parser.add_argument("--standards", type=Path, help="Workbook that contains a Standards sheet")
    parser.add_argument("--demo", choices=sorted(DATASETS), help="Run a bundled sample dataset")
    parser.add_argument("--out", type=Path, default=Path("validation_results.xlsx"))
    parser.add_argument("--json", action="store_true", help="Print the run as JSON")
    args = parser.parse_args(argv)

    if args.demo:
        products_bytes, standards_bytes = read_dataset(args.demo)
        result = run_validation_from_bytes(products_bytes, standards_bytes)
    else:
        if not args.products or not args.standards:
            parser.error("either --demo or both --products and --standards are required")
        result = run_validation_from_paths(args.products, args.standards)

    payload = result_to_payload(result)
    if args.json:
        json.dump(payload, sys.stdout, ensure_ascii=False, indent=2)
        sys.stdout.write("\n")

    if not payload["ok"]:
        print(payload["error"]["message"], file=sys.stderr)
        return 1

    assert isinstance(result, EngineSuccess)
    args.out.write_bytes(workbook_bytes(result.run))
    summary = result.run.summary
    message = (
        f"Wrote {args.out}  —  {summary.approved} approved / {summary.rejected} rejected / {summary.total} total"
    )
    print(message, file=sys.stderr if args.json else sys.stdout)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
