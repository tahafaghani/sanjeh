"""Header aliases — the only place identity/standard-table names are listed.

A new product parameter does not belong here. Parameters come from the
standards file; product columns are matched by normalized header name.
"""

IDENTITY_FIELDS = {
    "id": ("id", "product_id", "sku", "code", "کد", "شناسه"),
    "name": (
        "product",
        "name",
        "product_name",
        "title",
        "نام",
        "نام_محصول",
        "محصول",
    ),
    "category": ("category", "cat", "group", "دسته", "دسته_بندی", "دسته‌بندی"),
}

STANDARD_FIELDS = {
    "category": IDENTITY_FIELDS["category"],
    "parameter": ("parameter", "param", "field", "column", "پارامتر"),
    "min": ("min_value", "min", "minimum", "from", "حداقل"),
    "max": ("max_value", "max", "maximum", "to", "حداکثر"),
    "unit": ("unit", "units", "uom", "واحد"),
}

PRODUCT_SHEET_NAMES = ("products", "product", "محصولات", "محصول")
STANDARD_SHEET_NAMES = (
    "standards",
    "standard",
    "rules",
    "استانداردها",
    "استاندارد",
)
