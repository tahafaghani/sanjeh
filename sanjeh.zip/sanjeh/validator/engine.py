from __future__ import annotations

from collections import defaultdict

from validator.normalize import lookup_by_name, normalize_header, parse_number
from validator.types import (
    CheckFailure,
    ParameterCheck,
    ProductRecord,
    ProductValidation,
    StandardRule,
    ValidationRun,
    ValidationSummary,
)


def rules_by_category(standards: list[StandardRule]) -> dict[str, list[StandardRule]]:
    indexed: dict[str, list[StandardRule]] = defaultdict(list)
    for rule in standards:
        indexed[normalize_header(rule.category)].append(rule)
    return indexed


def check_rule(product: ProductRecord, rule: StandardRule) -> ParameterCheck:
    """Inclusive numeric range: Min <= value <= Max.

    Additional rule kinds belong in a registry keyed off a future Type column,
    not as scattered if/else around this loop.
    """
    found, actual = lookup_by_name(product.values, rule.parameter)

    if not found:
        failure = CheckFailure(
            parameter=rule.parameter,
            actual=None,
            min=rule.min,
            max=rule.max,
            unit=rule.unit,
            code="missing_parameter",
        )
        return ParameterCheck(
            parameter=rule.parameter,
            actual=None,
            min=rule.min,
            max=rule.max,
            unit=rule.unit,
            passed=False,
            failure=failure,
        )

    if actual is None or actual == "":
        failure = CheckFailure(
            parameter=rule.parameter,
            actual=actual,
            min=rule.min,
            max=rule.max,
            unit=rule.unit,
            code="missing_value",
        )
        return ParameterCheck(
            parameter=rule.parameter,
            actual=actual,
            min=rule.min,
            max=rule.max,
            unit=rule.unit,
            passed=False,
            failure=failure,
        )

    numeric = parse_number(actual)
    if numeric is None:
        failure = CheckFailure(
            parameter=rule.parameter,
            actual=actual,
            min=rule.min,
            max=rule.max,
            unit=rule.unit,
            code="not_numeric",
        )
        return ParameterCheck(
            parameter=rule.parameter,
            actual=actual,
            min=rule.min,
            max=rule.max,
            unit=rule.unit,
            passed=False,
            failure=failure,
        )

    passed = rule.min <= numeric <= rule.max
    failure = None
    if not passed:
        failure = CheckFailure(
            parameter=rule.parameter,
            actual=numeric,
            min=rule.min,
            max=rule.max,
            unit=rule.unit,
            code="out_of_range",
        )

    return ParameterCheck(
        parameter=rule.parameter,
        actual=numeric,
        min=rule.min,
        max=rule.max,
        unit=rule.unit,
        passed=passed,
        failure=failure,
    )


def validate_product(
    product: ProductRecord,
    standards: list[StandardRule],
    indexed: dict[str, list[StandardRule]] | None = None,
) -> ProductValidation:
    by_category = indexed if indexed is not None else rules_by_category(standards)
    rules = by_category.get(normalize_header(product.category), [])

    if not product.category or not rules:
        failure = CheckFailure(
            parameter="Category",
            actual=product.category or None,
            min=None,
            max=None,
            unit="",
            code="unknown_category",
        )
        return ProductValidation(
            id=product.id,
            name=product.name,
            category=product.category,
            status="REJECTED",
            failed_count=1,
            checks=[],
            failures=[failure],
        )

    checks = [check_rule(product, rule) for rule in rules]
    failures = [check.failure for check in checks if check.failure]
    return ProductValidation(
        id=product.id,
        name=product.name,
        category=product.category,
        status="APPROVED" if not failures else "REJECTED",
        failed_count=len(failures),
        checks=checks,
        failures=failures,
    )


def summarize(results: list[ProductValidation]) -> ValidationSummary:
    counts: dict[str, int] = defaultdict(int)
    approved = 0
    for result in results:
        if result.status == "APPROVED":
            approved += 1
        for failure in result.failures:
            counts[failure.parameter] += 1

    failures_by_parameter = [
        {"parameter": parameter, "count": count}
        for parameter, count in sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    ]
    return ValidationSummary(
        total=len(results),
        approved=approved,
        rejected=len(results) - approved,
        failures_by_parameter=failures_by_parameter,
    )


def validate_products(
    products: list[ProductRecord],
    standards: list[StandardRule],
) -> ValidationRun:
    indexed = rules_by_category(standards)
    results = [validate_product(product, standards, indexed) for product in products]
    return ValidationRun(
        products=products,
        standards=standards,
        results=results,
        summary=summarize(results),
    )
