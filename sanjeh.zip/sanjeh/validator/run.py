from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from validator.engine import validate_products
from validator.loader import workbook_from_bytes, workbook_from_path
from validator.parse import find_product_sheet, find_standard_sheet, parse_products, parse_standards
from validator.types import ParsedWorkbook, ParseIssue, ValidationRun


@dataclass
class LoadError:
    kind: str
    message: str
    issues: list[ParseIssue]


@dataclass
class EngineSuccess:
    ok: bool
    run: ValidationRun
    issues: list[ParseIssue]


@dataclass
class EngineFailure:
    ok: bool
    error: LoadError


EngineResult = EngineSuccess | EngineFailure


def run_validation(
    products_workbook: ParsedWorkbook,
    standards_workbook: ParsedWorkbook,
) -> EngineResult:
    product_sheet = find_product_sheet(products_workbook)
    standard_sheet = find_standard_sheet(standards_workbook)
    issues: list[ParseIssue] = []

    if product_sheet is None:
        return EngineFailure(
            ok=False,
            error=LoadError(kind="load", message="شیت Products در فایل محصولات پیدا نشد.", issues=issues),
        )
    if standard_sheet is None:
        return EngineFailure(
            ok=False,
            error=LoadError(kind="load", message="شیت Standards در فایل استاندارد پیدا نشد.", issues=issues),
        )

    products, product_issues = parse_products(product_sheet)
    standards, standard_issues = parse_standards(standard_sheet)
    issues.extend(product_issues)
    issues.extend(standard_issues)

    if not products:
        return EngineFailure(
            ok=False,
            error=LoadError(kind="load", message="هیچ محصولی در شیت Products نیست.", issues=issues),
        )
    if not standards:
        return EngineFailure(
            ok=False,
            error=LoadError(kind="load", message="هیچ استاندارد معتبری در شیت Standards نیست.", issues=issues),
        )

    return EngineSuccess(ok=True, run=validate_products(products, standards), issues=issues)


def run_validation_from_bytes(products_file: bytes, standards_file: bytes) -> EngineResult:
    return run_validation(workbook_from_bytes(products_file), workbook_from_bytes(standards_file))


def run_validation_from_paths(products_path: str | Path, standards_path: str | Path) -> EngineResult:
    return run_validation(workbook_from_path(products_path), workbook_from_path(standards_path))
