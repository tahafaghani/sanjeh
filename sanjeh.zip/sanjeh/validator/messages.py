from __future__ import annotations

from validator.types import CheckFailure


def _unit_suffix(unit: str) -> str:
    if not unit:
        return ""
    if len(unit) > 2:
        return f" {unit}"
    return unit


def format_failure_en(failure: CheckFailure) -> str:
    unit = _unit_suffix(failure.unit)
    code = failure.code
    if code == "unknown_category":
        return f"No standards defined for category '{failure.actual or ''}'"
    if code == "missing_parameter":
        return f"{failure.parameter}: missing from product (standard: {failure.min}-{failure.max}{unit})"
    if code == "missing_value":
        return f"{failure.parameter}: empty (standard: {failure.min}-{failure.max}{unit})"
    if code == "not_numeric":
        return f"{failure.parameter}: '{failure.actual}' is not a number"
    if code == "invalid_standard":
        return f"{failure.parameter}: standard row is invalid"
    return f"{failure.parameter}: {failure.actual}{unit}  Standard: {failure.min}-{failure.max}{unit}"


def format_failure_fa(failure: CheckFailure) -> str:
    unit = _unit_suffix(failure.unit)
    code = failure.code
    if code == "unknown_category":
        return f"برای دسته «{failure.actual or ''}» استانداردی تعریف نشده است"
    if code == "missing_parameter":
        return f"{failure.parameter} در محصول نیست (استاندارد: {failure.min}–{failure.max}{unit})"
    if code == "missing_value":
        return f"{failure.parameter} خالی است (استاندارد: {failure.min}–{failure.max}{unit})"
    if code == "not_numeric":
        return f"{failure.parameter}: مقدار «{failure.actual}» عددی نیست"
    if code == "invalid_standard":
        return f"{failure.parameter}: ردیف استاندارد نامعتبر است"
    return f"{failure.parameter}: مقدار {failure.actual}{unit} خارج از محدوده {failure.min}–{failure.max}{unit}"
