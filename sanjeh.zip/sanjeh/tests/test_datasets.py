from __future__ import annotations

from validator.run import EngineSuccess, run_validation_from_paths
from validator.samples import DATASETS


def _codes(result, product_id: str) -> list[str]:
    row = next(item for item in result.results if item.id == product_id)
    return [failure.parameter for failure in row.failures]


def _status_map(run) -> dict[str, str]:
    return {item.id: item.status for item in run.results}


def test_document_dataset_matches_spec_example():
    result = run_validation_from_paths(
        DATASETS["document"]["products"],
        DATASETS["document"]["standards"],
    )
    assert isinstance(result, EngineSuccess)
    status = _status_map(result.run)
    assert status == {
        "P001": "APPROVED",
        "P002": "REJECTED",
        "P003": "REJECTED",
        "P004": "APPROVED",
        "P005": "APPROVED",
        "P006": "REJECTED",
        "P007": "APPROVED",
        "P008": "APPROVED",
    }
    assert _codes(result.run, "P002") == ["Weight_g", "Quality_Score"]
    assert _codes(result.run, "P003") == ["Quality_Score"]
    assert _codes(result.run, "P006") == ["Weight_g", "Length_cm", "Quality_Score"]


def test_products_dataset_expected_table():
    result = run_validation_from_paths(
        DATASETS["products"]["products"],
        DATASETS["products"]["standards"],
    )
    assert isinstance(result, EngineSuccess)
    status = _status_map(result.run)
    assert status == {
        "P001": "APPROVED",
        "P002": "REJECTED",
        "P003": "APPROVED",
        "P004": "REJECTED",
        "P005": "REJECTED",
        "P006": "REJECTED",
        "P007": "REJECTED",
        "P008": "REJECTED",
    }
    assert _codes(result.run, "P002") == ["Weight_g", "Quality_Score"]
    assert _codes(result.run, "P004") == ["Length_cm", "Width_cm"]
