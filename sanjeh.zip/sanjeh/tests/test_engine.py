from __future__ import annotations

from validator.engine import validate_product, validate_products
from validator.types import ProductRecord, StandardRule


def _product(**values) -> ProductRecord:
    category = values.pop("category", "A")
    return ProductRecord(
        id=values.pop("id", "P001"),
        name=values.pop("name", "Sample"),
        category=category,
        values=values,
        source_row=2,
    )


STANDARDS = [
    StandardRule(category="A", parameter="Weight_g", min=900, max=1100, unit="g"),
    StandardRule(category="A", parameter="Quality_Score", min=90, max=100, unit="score"),
]


def test_inclusive_bounds_pass():
    low = validate_product(_product(Weight_g=900, Quality_Score=90), STANDARDS)
    high = validate_product(_product(Weight_g=1100, Quality_Score=100), STANDARDS)
    assert low.status == "APPROVED"
    assert high.status == "APPROVED"


def test_out_of_range_rejects_with_reason():
    result = validate_product(_product(Weight_g=1250, Quality_Score=88), STANDARDS)
    assert result.status == "REJECTED"
    assert result.failed_count == 2


def test_unknown_category_rejected():
    result = validate_product(_product(category="Z", Weight_g=980, Quality_Score=92), STANDARDS)
    assert result.status == "REJECTED"
    assert result.failures[0].code == "unknown_category"


def test_extra_column_without_standard_is_ignored():
    result = validate_product(
        _product(Weight_g=980, Quality_Score=92, Color="red", Price=12),
        STANDARDS,
    )
    assert result.status == "APPROVED"


def test_new_parameter_works_without_code_change():
    product = _product(Weight_g=980, Quality_Score=92, Height_cm=40)
    standards = STANDARDS + [
        StandardRule(category="A", parameter="Height_cm", min=30, max=50, unit="cm")
    ]
    result = validate_product(product, standards)
    assert result.status == "APPROVED"
