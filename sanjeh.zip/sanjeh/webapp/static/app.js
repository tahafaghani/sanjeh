const state = {
  demo: "products",
  productsFile: null,
  standardsFile: null,
  xlsx: null,
};

const $ = (id) => document.getElementById(id);

function setStatus(text) {
  $("status-line").textContent = text;
}

function escapeHtml(value) {
  const node = document.createElement("span");
  node.textContent = String(value);
  return node.innerHTML;
}

/** نام پارامتر خوانا: Quality_Score → Quality Score ، Width_cm → Width */
function prettyParameter(name) {
  if (!name) return "";
  const known = {
    Quality_Score: "Quality Score",
    Weight_g: "Weight",
    Length_cm: "Length",
    Width_cm: "Width",
    Height_cm: "Height",
  };
  if (known[name]) return known[name];
  return String(name)
    .replace(/_/g, " ")
    .replace(/\b(cm|mm|m|g|kg|score|pct|percent)\b/gi, "")
    .replace(/\s+/g, " ")
    .trim();
}

/** مقدار + واحد با فاصله: 11 cm ؛ برای score فقط عدد */
function formatValue(actual, unit) {
  if (actual == null || actual === "") return "—";
  const u = String(unit || "").trim();
  if (!u) return String(actual);
  if (u.toLowerCase() === "score") return String(actual);
  return String(actual) + " " + u;
}

function setUploadBar(kind, { percent, status, message }) {
  const track = $("track-" + kind);
  const fill = $("fill-" + kind);
  const msg = $("msg-" + kind);
  if (!track || !fill || !msg) return;

  track.hidden = false;
  track.classList.remove("is-ok", "is-bad", "is-busy");
  msg.classList.remove("is-ok", "is-bad");

  const pct = Math.max(0, Math.min(100, Number(percent) || 0));
  fill.style.width = pct + "%";

  if (status === "ok") {
    track.classList.add("is-ok");
    msg.classList.add("is-ok");
  } else if (status === "bad") {
    track.classList.add("is-bad");
    msg.classList.add("is-bad");
  } else if (status === "busy") {
    track.classList.add("is-busy");
  }

  msg.textContent = message || "";
}

function bindDrop(inputId, dropId, nameId, key, barKind) {
  const input = $(inputId);
  const drop = $(dropId);
  const label = $(nameId);

  const assign = (file) => {
    if (!file) return;
    const okType = /\.(xlsx|xlsm|xls)$/i.test(file.name);
    state[key] = okType ? file : null;
    if (okType) {
      drop.classList.add("is-on");
      label.textContent = file.name;
      setUploadBar(barKind, {
        percent: 100,
        status: "ok",
        message: "آپلود موفق — فایل آماده است",
      });
    } else {
      drop.classList.remove("is-on");
      label.textContent = "فرمت نامعتبر؛ فقط Excel";
      setUploadBar(barKind, {
        percent: 100,
        status: "bad",
        message: "آپلود ناموفق — فقط فایل Excel بفرستید",
      });
    }
  };

  input.addEventListener("change", () => assign(input.files && input.files[0]));
  drop.addEventListener("dragover", (event) => {
    event.preventDefault();
    drop.classList.add("is-on");
  });
  drop.addEventListener("dragleave", () => {
    if (!state[key]) drop.classList.remove("is-on");
  });
  drop.addEventListener("drop", (event) => {
    event.preventDefault();
    assign(event.dataTransfer && event.dataTransfer.files && event.dataTransfer.files[0]);
  });
}

function postJson(url, body) {
  setStatus("در حال اجرای موتور قطعی…");
  $("error").hidden = true;
  return fetch(url, {
    method: "POST",
    body: JSON.stringify(body),
    headers: { "Content-Type": "application/json" },
  }).then(async (response) => {
    const payload = await response.json();
    if (!payload.ok) {
      const message =
        payload.error && payload.error.message ? payload.error.message : "اعتبارسنجی ناموفق بود.";
      throw new Error(message);
    }
    return payload;
  });
}

/** آپلود با درصد پیشرفت واقعی به سرور */
function postFormWithProgress(url, formData) {
  setStatus("در حال ارسال فایل‌ها و اجرای موتور…");
  $("error").hidden = true;

  setUploadBar("products", { percent: 0, status: "busy", message: "در حال ارسال…" });
  setUploadBar("standards", { percent: 0, status: "busy", message: "در حال ارسال…" });

  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", url);

    xhr.upload.onprogress = (event) => {
      if (!event.lengthComputable) return;
      const pct = Math.round((event.loaded / event.total) * 100);
      const msg = "ارسال فایل‌ها: " + pct + "٪";
      setUploadBar("products", { percent: pct, status: "busy", message: msg });
      setUploadBar("standards", { percent: pct, status: "busy", message: msg });
    };

    xhr.onload = () => {
      let payload;
      try {
        payload = JSON.parse(xhr.responseText || "{}");
      } catch (_) {
        setUploadBar("products", { percent: 100, status: "bad", message: "پاسخ سرور نامعتبر بود" });
        setUploadBar("standards", { percent: 100, status: "bad", message: "پاسخ سرور نامعتبر بود" });
        reject(new Error("پاسخ سرور نامعتبر بود."));
        return;
      }

      if (xhr.status >= 200 && xhr.status < 300 && payload.ok) {
        setUploadBar("products", { percent: 100, status: "ok", message: "ارسال موفق" });
        setUploadBar("standards", { percent: 100, status: "ok", message: "ارسال موفق" });
        resolve(payload);
        return;
      }

      const message =
        payload.error && payload.error.message ? payload.error.message : "اعتبارسنجی ناموفق بود.";
      setUploadBar("products", { percent: 100, status: "bad", message: "ارسال ناموفق" });
      setUploadBar("standards", { percent: 100, status: "bad", message: "ارسال ناموفق" });
      reject(new Error(message));
    };

    xhr.onerror = () => {
      setUploadBar("products", { percent: 100, status: "bad", message: "خطای شبکه در آپلود" });
      setUploadBar("standards", { percent: 100, status: "bad", message: "خطای شبکه در آپلود" });
      reject(new Error("ارتباط با سرور برقرار نشد."));
    };

    xhr.send(formData);
  });
}

function render(payload) {
  const run = payload.run;
  $("stats").hidden = false;
  $("ledger").hidden = false;
  $("stat-total").textContent = String(run.summary.total);
  $("stat-ok").textContent = String(run.summary.approved);
  $("stat-bad").textContent = String(run.summary.rejected);

  const top = run.summary.failures_by_parameter && run.summary.failures_by_parameter[0];
  if (top) {
    $("stat-top").textContent =
      prettyParameter(top.parameter) + " — " + top.count + " مورد";
  } else {
    $("stat-top").textContent = "بدون مغایرت";
  }

  $("ledger-sub").textContent =
    run.summary.approved + " تأیید، " + run.summary.rejected + " رد از " + run.summary.total + " محصول";

  const issues = payload.issues || [];
  if (issues.length) {
    $("issues").hidden = false;
    $("issues").textContent = issues.map((item) => item.message).join(" · ");
  } else {
    $("issues").hidden = true;
  }

  const rows = $("rows");
  rows.innerHTML = "";
  for (const item of run.results) {
    const tr = document.createElement("tr");
    const reasons =
      item.reasons_fa && item.reasons_fa.length
        ? '<ul class="reasons">' +
          item.reasons_fa.map((text) => "<li>" + escapeHtml(text) + "</li>").join("") +
          "</ul>"
        : "—";

    const chips = (item.checks || [])
      .map((check) => {
        const klass = check.passed ? "pass" : "fail";
        const label =
          prettyParameter(check.parameter) + " " + formatValue(check.actual, check.unit || "");
        return '<span class="chip ' + klass + '">' + escapeHtml(label) + "</span>";
      })
      .join("");

    const stampClass = item.status === "APPROVED" ? "ok" : "bad";
    const stampText = item.status === "APPROVED" ? "تأیید" : "رد";

    tr.innerHTML =
      '<td class="tabular">' +
      escapeHtml(item.id) +
      "</td><td>" +
      escapeHtml(item.name) +
      "</td><td>" +
      escapeHtml(item.category || "—") +
      '</td><td><span class="stamp ' +
      stampClass +
      '">' +
      stampText +
      '</span></td><td class="tabular">' +
      item.failed_count +
      "</td><td>" +
      reasons +
      '<div class="checks">' +
      chips +
      "</div></td>";
    rows.appendChild(tr);
  }

  state.xlsx = payload.xlsx_base64 || null;
  $("btn-download").disabled = !state.xlsx;
  setStatus("گزارش آماده است. تصمیم‌ها از بازهٔ حداقل–حداکثر آمده‌اند.");
}

function downloadXlsx() {
  if (!state.xlsx) return;
  const bytes = Uint8Array.from(atob(state.xlsx), (char) => char.charCodeAt(0));
  const blob = new Blob([bytes], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "validation_results.xlsx";
  link.click();
  URL.revokeObjectURL(url);
}

async function runUploads() {
  if (!state.productsFile || !state.standardsFile) {
    throw new Error("ابتدا هر دو فایل Excel را انتخاب کنید، یا دیتاست Products را اجرا کنید.");
  }
  const body = new FormData();
  body.append("products", state.productsFile);
  body.append("standards", state.standardsFile);
  return postFormWithProgress("/api/validate", body);
}

async function runDemo() {
  return postJson("/api/demo", { dataset: "products" });
}

async function handle(job) {
  $("btn-run").disabled = true;
  $("btn-demo").disabled = true;
  try {
    const payload = await job();
    render(payload);
  } catch (error) {
    $("error").hidden = false;
    $("error").textContent = error.message;
    setStatus("اجرا متوقف شد.");
  } finally {
    $("btn-run").disabled = false;
    $("btn-demo").disabled = false;
  }
}

bindDrop("file-products", "drop-products", "name-products", "productsFile", "products");
bindDrop("file-standards", "drop-standards", "name-standards", "standardsFile", "standards");

$("btn-run").addEventListener("click", () => handle(runUploads));
$("btn-demo").addEventListener("click", () => handle(runDemo));
$("btn-download").addEventListener("click", downloadXlsx);

// handle(runDemo);

// =============================
// const state = {
//   demo: "document",
//   productsFile: null,
//   standardsFile: null,
//   xlsx: null,
// };

// const $ = (id) => document.getElementById(id);

// function setStatus(text) {
//   $("status-line").textContent = text;
// }

// function escapeHtml(value) {
//   const node = document.createElement("span");
//   node.textContent = String(value);
//   return node.innerHTML;
// }

// function bindDrop(inputId, dropId, nameId, key) {
//   const input = $(inputId);
//   const drop = $(dropId);
//   const label = $(nameId);

//   const assign = (file) => {
//     if (!file) return;
//     state[key] = file;
//     drop.classList.add("is-on");
//     label.textContent = file.name;
//   };

//   input.addEventListener("change", () => assign(input.files && input.files[0]));
//   drop.addEventListener("dragover", (event) => {
//     event.preventDefault();
//     drop.classList.add("is-on");
//   });
//   drop.addEventListener("dragleave", () => {
//     if (!state[key]) drop.classList.remove("is-on");
//   });
//   drop.addEventListener("drop", (event) => {
//     event.preventDefault();
//     assign(event.dataTransfer && event.dataTransfer.files && event.dataTransfer.files[0]);
//   });
// }

// function selectDemo(id) {
//   state.demo = id;
//   document.querySelectorAll(".seg-btn").forEach((button) => {
//     button.classList.toggle("is-on", button.dataset.demo === id);
//   });
// }

// async function postForm(url, body, isJson) {
//   setStatus("در حال اجرای موتور قطعی…");
//   $("error").hidden = true;
//   const headers = {};
//   if (isJson) headers["Content-Type"] = "application/json";
//   const response = await fetch(url, { method: "POST", body: body, headers: headers });
//   const payload = await response.json();
//   if (!payload.ok) {
//     const message = payload.error && payload.error.message ? payload.error.message : "اعتبارسنجی ناموفق بود.";
//     throw new Error(message);
//   }
//   return payload;
// }

// function unitLabel(unit) {
//   if (!unit) return "";
//   return unit.length > 2 ? " " + unit : unit;
// }

// function render(payload) {
//   const run = payload.run;
//   $("stats").hidden = false;
//   $("ledger").hidden = false;
//   $("stat-total").textContent = String(run.summary.total);
//   $("stat-ok").textContent = String(run.summary.approved);
//   $("stat-bad").textContent = String(run.summary.rejected);
//   const top = run.summary.failures_by_parameter && run.summary.failures_by_parameter[0];
//   $("stat-top").textContent = top ? top.parameter + " × " + top.count : "بدون مغایرت";
//   $("ledger-sub").textContent =
//     run.summary.approved + " تأیید، " + run.summary.rejected + " رد از " + run.summary.total + " محصول";

//   const issues = payload.issues || [];
//   if (issues.length) {
//     $("issues").hidden = false;
//     $("issues").textContent = issues.map((item) => item.message).join(" · ");
//   } else {
//     $("issues").hidden = true;
//   }

//   const rows = $("rows");
//   rows.innerHTML = "";
//   for (const item of run.results) {
//     const tr = document.createElement("tr");
//     const reasons = item.reasons_fa && item.reasons_fa.length
//       ? '<ul class="reasons">' + item.reasons_fa.map((text) => "<li>" + escapeHtml(text) + "</li>").join("") + "</ul>"
//       : "—";
//     const chips = (item.checks || [])
//       .map((check) => {
//         const klass = check.passed ? "pass" : "fail";
//         const actual = check.actual == null || check.actual === "" ? "—" : check.actual;
//         return (
//           '<span class="chip ' +
//           klass +
//           '">' +
//           escapeHtml(check.parameter) +
//           " " +
//           escapeHtml(actual) +
//           escapeHtml(unitLabel(check.unit || "")) +
//           "</span>"
//         );
//       })
//       .join("");
//     const stampClass = item.status === "APPROVED" ? "ok" : "bad";
//     const stampText = item.status === "APPROVED" ? "تأیید" : "رد";
//     tr.innerHTML =
//       '<td class="tabular">' +
//       escapeHtml(item.id) +
//       "</td><td>" +
//       escapeHtml(item.name) +
//       "</td><td>" +
//       escapeHtml(item.category || "—") +
//       "</td><td><span class=\"stamp " +
//       stampClass +
//       '">' +
//       stampText +
//       '</span></td><td class="tabular">' +
//       item.failed_count +
//       "</td><td>" +
//       reasons +
//       '<div class="checks">' +
//       chips +
//       "</div></td>";
//     rows.appendChild(tr);
//   }

//   state.xlsx = payload.xlsx_base64 || null;
//   $("btn-download").disabled = !state.xlsx;
//   setStatus("گزارش آماده است. تصمیم‌ها از بازهٔ حداقل–حداکثر آمده‌اند.");
// }

// function downloadXlsx() {
//   if (!state.xlsx) return;
//   const bytes = Uint8Array.from(atob(state.xlsx), (char) => char.charCodeAt(0));
//   const blob = new Blob([bytes], {
//     type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
//   });
//   const url = URL.createObjectURL(blob);
//   const link = document.createElement("a");
//   link.href = url;
//   link.download = "validation_results.xlsx";
//   link.click();
//   URL.revokeObjectURL(url);
// }

// async function runUploads() {
//   if (!state.productsFile || !state.standardsFile) {
//     throw new Error("ابتدا هر دو فایل Excel را انتخاب کنید، یا دیتاست نمونه را اجرا کنید.");
//   }
//   const body = new FormData();
//   body.append("products", state.productsFile);
//   body.append("standards", state.standardsFile);
//   return postForm("/api/validate", body, false);
// }

// async function runDemo() {
//   return postForm("/api/demo", JSON.stringify({ dataset: state.demo }), true);
// }

// async function handle(job) {
//   $("btn-run").disabled = true;
//   $("btn-demo").disabled = true;
//   try {
//     const payload = await job();
//     render(payload);
//   } catch (error) {
//     $("error").hidden = false;
//     $("error").textContent = error.message;
//     setStatus("اجرا متوقف شد.");
//   } finally {
//     $("btn-run").disabled = false;
//     $("btn-demo").disabled = false;
//   }
// }

// bindDrop("file-products", "drop-products", "name-products", "productsFile");
// bindDrop("file-standards", "drop-standards", "name-standards", "standardsFile");

// document.querySelectorAll(".seg-btn").forEach((button) => {
//   button.addEventListener("click", () => selectDemo(button.dataset.demo));
// });
// $("btn-run").addEventListener("click", () => handle(runUploads));
// $("btn-demo").addEventListener("click", () => handle(runDemo));
// $("btn-download").addEventListener("click", downloadXlsx);

// handle(runDemo);
