from __future__ import annotations

import base64
from pathlib import Path

from fastapi import FastAPI, File, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from validator.reporter import workbook_bytes
from validator.run import EngineSuccess, run_validation_from_bytes
from validator.samples import dataset_meta, read_dataset
from validator.serialize import result_to_payload

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent
STATIC = ROOT / "static"
TEMPLATES = ROOT / "templates"

app = FastAPI(title="سنجه", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=str(STATIC)), name="static")


class DemoRequest(BaseModel):
    dataset: str = Field(default="document")


def _payload_with_xlsx(result) -> dict:
    payload = result_to_payload(result)
    if isinstance(result, EngineSuccess) and payload["ok"]:
        payload["xlsx_base64"] = base64.b64encode(workbook_bytes(result.run)).decode("ascii")
        payload["filename"] = "validation_results.xlsx"
    return payload


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/")
def index() -> HTMLResponse:
    return HTMLResponse((TEMPLATES / "index.html").read_text(encoding="utf-8"))


@app.get("/favicon.svg")
def favicon() -> FileResponse:
    return FileResponse(STATIC / "favicon.svg", media_type="image/svg+xml")


@app.get("/api/samples")
def samples() -> dict:
    return {"datasets": dataset_meta()}


@app.post("/api/demo")
def run_demo(body: DemoRequest) -> JSONResponse:
    try:
        products, standards = read_dataset(body.dataset)
    except KeyError:
        return JSONResponse({"ok": False, "error": {"message": "دیتاست نمونه پیدا نشد."}}, status_code=400)
    result = run_validation_from_bytes(products, standards)
    status = 200 if (isinstance(result, EngineSuccess) and result.ok) else 400
    return JSONResponse(_payload_with_xlsx(result), status_code=status)


@app.post("/api/validate")
async def validate(
    products: UploadFile = File(...),
    standards: UploadFile = File(...),
) -> JSONResponse:
    products_bytes = await products.read()
    standards_bytes = await standards.read()
    if not products_bytes or not standards_bytes:
        return JSONResponse(
            {"ok": False, "error": {"message": "هر دو فایل محصولات و استاندارد لازم است."}},
            status_code=400,
        )
    result = run_validation_from_bytes(products_bytes, standards_bytes)
    status = 200 if (isinstance(result, EngineSuccess) and result.ok) else 400
    return JSONResponse(_payload_with_xlsx(result), status_code=status)


@app.get("/{full_path:path}")
def spa_fallback(full_path: str):
    if full_path.startswith("static/"):
        return Response(status_code=404)
    return HTMLResponse((TEMPLATES / "index.html").read_text(encoding="utf-8"))
